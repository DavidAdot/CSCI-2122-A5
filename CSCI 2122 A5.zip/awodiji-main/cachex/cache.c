#include "cache.h"
#include "string.h"
#include "stddef.h"

// Counter for the cache hits
static int hits;

// Counter for the cache misses
static int misses;

// Initialize the cache
void init_cache() {

    // Initialize cache memory
    memset(c_info.F_memory, 0, c_info.F_size);
}

int cache_get(unsigned long address, unsigned long *value) {

    // Check if the address is in range and value is not NULL
    if (address >= c_info.M_size || value == NULL) {
        // Return 0 if the address is out of range or if the value is NULL
        return 0;
    }

    // Check if the cache system has been initialized
    if (c_info.F_memory == NULL) {
        // Initialize the cache if it is not made already
        init_cache();
    }

    // Simulate memory access by calling memget
    unsigned long word;
    if (!memget(address, &word, sizeof(unsigned long))) {
        // Return 0 if memget fails
        return 0;
    }

    // Update cache statistics based on the result of memory access
    if (*value == word) {
        //Increment the cache hit counter
        hits++;
    } else {
        //Increment the cache miss counter
        misses++;
    }

    // Copy the retrieved value into the proper location
    *value = word;

    // Return statement
    return 1;
}
